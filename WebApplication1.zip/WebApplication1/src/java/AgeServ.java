

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AgeServ extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        }
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
         try
        {
        Connection con=connect();
        
        
        String query="SELECT * FROM STUDENTINFO WHERE AGE BETWEEN 10 AND 20 ORDER BY MARKS DESC LIMIT 5";
        
        PreparedStatement pstmt=con.prepareStatement(query);
            ResultSet rs=pstmt.executeQuery();
            
             PrintWriter out=response.getWriter();
            out.println("<center>Age between 10 to 20</center>");
            out.println("<table border='1' align='center'>");
             out.println("<tr><td>Age</td><td>Name</td><td>Marks</td><td>City</td></tr>");
             
            while(rs.next())
            {      
                out.print("<tr><td>"+rs.getInt("age")+"</td>");                
                out.print("<td>"+rs.getString("name")+"</td>");
                out.print("<td>"+rs.getInt("marks")+"</td>");
                out.print("<td>"+rs.getString("city")+"</td></tr>");
            }
            out.println("</table>");
            
            out.println("<br><br><br>");
            
             String que="SELECT * FROM STUDENTINFO WHERE AGE BETWEEN 20 AND 30 ORDER BY MARKS DESC LIMIT 5";
            pstmt=con.prepareStatement(que);
            rs=pstmt.executeQuery();
            
             out.println("<center>Age between 20 to 30</center>");
            out.println("<table border='1' align='center'>");
             out.println("<tr><td>Age</td><td>Name</td><td>Marks</td><td>City</td></tr>");
             
            while(rs.next())
            {      
                out.print("<tr><td>"+rs.getInt("age")+"</td>");                
                out.print("<td>"+rs.getString("name")+"</td>");
                out.print("<td>"+rs.getInt("marks")+"</td>");
                out.print("<td>"+rs.getString("city")+"</td></tr>");
            }
            
             out.println("</table>");
            
              out.println("<br><br><br>");
            
             String qu="SELECT * FROM STUDENTINFO WHERE AGE BETWEEN 30 AND 60 ORDER BY MARKS DESC LIMIT 5";
            pstmt=con.prepareStatement(qu);
            rs=pstmt.executeQuery();
            
             out.println("<center>Age between 30 to 60</center>");
            out.println("<table border='1' align='center'>");
             out.println("<tr><td>Age</td><td>Name</td><td>Marks</td><td>City</td></tr>");
             
            while(rs.next())
            {      
                out.print("<tr><td>"+rs.getInt("age")+"</td>");                
                out.print("<td>"+rs.getString("name")+"</td>");
                out.print("<td>"+rs.getInt("marks")+"</td>");
                out.print("<td>"+rs.getString("city")+"</td></tr>");
            }
            
             out.println("</table>");
            
            
            
            
            
            
            
            
            
            
        }
         catch(Exception e)
         {
             e.printStackTrace();
         }
        
        
    }
    
        public Connection connect()
	{
		Connection con=null;
		try
		{
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost/student","root","");
		System.out.println("Connection established");
		return con;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return con;
		
	}
   
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
